create view customer_list as
select `cu`.`customer_id`                               AS `ID`,
       concat(`cu`.`first_name`, ' ', `cu`.`last_name`) AS `name`,
       `a`.`address`                                    AS `address`,
       `a`.`postal_code`                                AS `zip code`,
       `a`.`phone`                                      AS `phone`,
       `decine`.`city`.`city`                           AS `city`,
       `decine`.`country`.`country`                     AS `country`,
       if(`cu`.`active`, 'active', '')                  AS `notes`,
       `cu`.`store_id`                                  AS `SID`
from (((`decine`.`customer` `cu` join `decine`.`address` `a` on (`cu`.`address_id` = `a`.`address_id`)) join `decine`.`city` on (`a`.`city_id` = `decine`.`city`.`city_id`))
         join `decine`.`country` on (`decine`.`city`.`country_id` = `decine`.`country`.`country_id`));

