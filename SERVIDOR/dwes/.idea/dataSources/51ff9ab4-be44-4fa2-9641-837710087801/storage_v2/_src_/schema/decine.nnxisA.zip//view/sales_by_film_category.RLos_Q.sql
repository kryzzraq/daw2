create view sales_by_film_category as
select `c`.`name` AS `category`, sum(`p`.`amount`) AS `total_sales`
from (((((`decine`.`payment` `p` join `decine`.`rental` `r` on (`p`.`rental_id` = `r`.`rental_id`)) join `decine`.`inventory` `i` on (`r`.`inventory_id` = `i`.`inventory_id`)) join `decine`.`film` `f` on (`i`.`film_id` = `f`.`film_id`)) join `decine`.`film_category` `fc` on (`f`.`film_id` = `fc`.`film_id`))
         join `decine`.`category` `c` on (`fc`.`category_id` = `c`.`category_id`))
group by `c`.`name`
order by sum(`p`.`amount`) desc;

