create view nicer_but_slower_film_list as
select `decine`.`film`.`film_id`                                                                                 AS `FID`,
       `decine`.`film`.`title`                                                                                   AS `title`,
       `decine`.`film`.`description`                                                                             AS `description`,
       `decine`.`category`.`name`                                                                                AS `category`,
       `decine`.`film`.`rental_rate`                                                                             AS `price`,
       `decine`.`film`.`length`                                                                                  AS `length`,
       `decine`.`film`.`rating`                                                                                  AS `rating`,
       group_concat(concat(concat(ucase(substr(`decine`.`actor`.`first_name`, 1, 1)), lcase(
               substr(`decine`.`actor`.`first_name`, 2, octet_length(`decine`.`actor`.`first_name`))), ' ',
                                  concat(ucase(substr(`decine`.`actor`.`last_name`, 1, 1)), lcase(
                                          substr(`decine`.`actor`.`last_name`, 2,
                                                 octet_length(`decine`.`actor`.`last_name`)))))) separator
                    ', ')                                                                                        AS `actors`
from ((((`decine`.`category` left join `decine`.`film_category` on (`decine`.`category`.`category_id` =
                                                                    `decine`.`film_category`.`category_id`)) left join `decine`.`film` on (`decine`.`film_category`.`film_id` = `decine`.`film`.`film_id`)) join `decine`.`film_actor` on (`decine`.`film`.`film_id` = `decine`.`film_actor`.`film_id`))
         join `decine`.`actor` on (`decine`.`film_actor`.`actor_id` = `decine`.`actor`.`actor_id`))
group by `decine`.`film`.`film_id`;

