create view sales_by_store as
select concat(`c`.`city`, ',', `cy`.`country`)        AS `store`,
       concat(`m`.`first_name`, ' ', `m`.`last_name`) AS `manager`,
       sum(`p`.`amount`)                              AS `total_sales`
from (((((((`decine`.`payment` `p` join `decine`.`rental` `r` on (`p`.`rental_id` = `r`.`rental_id`)) join `decine`.`inventory` `i` on (`r`.`inventory_id` = `i`.`inventory_id`)) join `decine`.`store` `s` on (`i`.`store_id` = `s`.`store_id`)) join `decine`.`address` `a` on (`s`.`address_id` = `a`.`address_id`)) join `decine`.`city` `c` on (`a`.`city_id` = `c`.`city_id`)) join `decine`.`country` `cy` on (`c`.`country_id` = `cy`.`country_id`))
         join `decine`.`staff` `m` on (`s`.`manager_staff_id` = `m`.`staff_id`))
group by `s`.`store_id`
order by `cy`.`country`, `c`.`city`;

