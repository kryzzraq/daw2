create view staff_list as
select `s`.`staff_id`                                 AS `ID`,
       concat(`s`.`first_name`, ' ', `s`.`last_name`) AS `name`,
       `a`.`address`                                  AS `address`,
       `a`.`postal_code`                              AS `zip code`,
       `a`.`phone`                                    AS `phone`,
       `decine`.`city`.`city`                         AS `city`,
       `decine`.`country`.`country`                   AS `country`,
       `s`.`store_id`                                 AS `SID`
from (((`decine`.`staff` `s` join `decine`.`address` `a` on (`s`.`address_id` = `a`.`address_id`)) join `decine`.`city` on (`a`.`city_id` = `decine`.`city`.`city_id`))
         join `decine`.`country` on (`decine`.`city`.`country_id` = `decine`.`country`.`country_id`));

